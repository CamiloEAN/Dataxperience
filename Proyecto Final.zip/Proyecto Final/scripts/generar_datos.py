"""
generar_datos.py
-----------------
Genera un dataset simulado de telemetria de un motor DC: corriente (A) vs.
temperatura (°C), pensado para el proyecto de "refrigeracion preventiva".

Por que simulado y no un sensor real:
No se cuenta con un banco de pruebas fisico con motor + sensores de corriente
y temperatura instrumentados. Para poder desarrollar el proyecto, generamos datos 
sinteticos con un modelo fisico simplificado en vez de usar numeros arbitrarios.

Modelo fisico usado:
En estado estable, el calor generado por efecto Joule (P = I^2 * R) se
equilibra con la disipacion convectiva hacia el ambiente, por lo que la
temperatura del motor tiende a subir de forma parcialmente cuadratica con la
corriente:
    T(I) = T_ambiente + a*I + b*I^2 + ruido
Se uso "a" dominante (componente lineal, coherente con lo pedido en el curso:
regresion lineal simple) y un termino cuadratico "b" pequeño para reflejar,
de forma leve y realista el origen fisico I^2*R del calentamiento.

Ademas se inyecto un pequeño grupo de "picos de arranque" mediciones tomadas
justo al encender el motor (o en un ciclo de trabajo intermitente), donde la
temperatura registrada es mas alta de lo esperado para esa corriente porque el
motor no ha alcanzado equilibrio termico. Estos puntos quedan marcados en la
columna `evento` para que el analisis de outliers sea honesto (no solo
"buscamos outliers" sino que sabemos exactamente cuales son y por que).
"""

import numpy as np
import pandas as pd

SEED = 7
N_ESTABLE = 190
N_ARRANQUE = 10
T_AMBIENTE = 20.0   # °C, temperatura ambiente de referencia
A_LINEAL = 2.05     # °C por Amperio (componente dominante, lineal)
B_CUADRATICO = 0.018  # componente cuadratica leve (origen fisico I^2*R)
RUIDO_STD = 2.6     # °C, ruido de sensor / variabilidad térmica


def generar_dataset(seed: int = SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    # --- Mediciones en estado estable ---
    corriente_estable = rng.uniform(5, 25, N_ESTABLE)
    ruido = rng.normal(0, RUIDO_STD, N_ESTABLE)
    temp_estable = (
        T_AMBIENTE + A_LINEAL * corriente_estable
        + B_CUADRATICO * corriente_estable**2 + ruido
    )

    # --- Picos de arranque (motor aun no en equilibrio termico) ---
    corriente_arranque = rng.uniform(6, 20, N_ARRANQUE)
    sobre_temp = rng.uniform(14, 24, N_ARRANQUE)  # exceso de temperatura
    temp_arranque = (
        T_AMBIENTE + A_LINEAL * corriente_arranque
        + B_CUADRATICO * corriente_arranque**2 + sobre_temp
    )

    corriente = np.concatenate([corriente_estable, corriente_arranque])
    temperatura = np.concatenate([temp_estable, temp_arranque])
    evento = np.array(["estable"] * N_ESTABLE + ["arranque"] * N_ARRANQUE)

    df = pd.DataFrame({
        "Corriente_A": corriente,
        "Temperatura_C": temperatura,
        "evento": evento,
    })

    # mezclar filas para que no queden agrupadas por tipo de evento
    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)
    df["Corriente_A"] = df["Corriente_A"].round(3)
    df["Temperatura_C"] = df["Temperatura_C"].round(3)
    return df


if __name__ == "__main__":
    df = generar_dataset()
    df.to_csv("motor_sensor_data.csv", index=False)
    print(f"Dataset generado: {len(df)} registros -> motor_sensor_data.csv")
    print(df[["Corriente_A", "Temperatura_C"]].describe())
